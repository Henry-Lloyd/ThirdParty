import express from 'express';
import path from 'path';
import fs from 'fs';

export function setupStaticServing(app: express.Application) {
  console.log('Setting up static file serving for production...');
  
  const publicPath = path.join(process.cwd(), 'dist', 'public');
  const indexPath = path.join(publicPath, 'index.html');
  
  console.log('Public path:', publicPath);
  console.log('Index path:', indexPath);
  
  // Check if the build files exist
  if (!fs.existsSync(publicPath)) {
    console.error('❌ Build directory not found:', publicPath);
    console.error('Make sure to run "npm run build" before starting in production');
    return;
  }
  
  if (!fs.existsSync(indexPath)) {
    console.error('❌ Index.html not found:', indexPath);
    console.error('Make sure the build completed successfully');
    return;
  }
  
  // Serve static files from the build output
  app.use(express.static(publicPath, {
    maxAge: '1d', // Cache static assets for 1 day
    etag: true,
    lastModified: true
  }));
  
  // Handle client-side routing - serve index.html for all non-API routes
  app.get('/*splat', (req, res) => {
    // Skip API routes
    if (req.path.startsWith('/api')) {
      res.status(404).json({ error: 'API endpoint not found' });
      return;
    }
    
    console.log('Serving index.html for route:', req.path);
    res.sendFile(indexPath);
  });
  
  console.log('✅ Static file serving configured successfully');
}
