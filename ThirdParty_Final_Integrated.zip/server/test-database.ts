import { db } from './database.js';
import { sql } from 'kysely';

// Test script to verify database operations
async function testDatabaseOperations() {
  console.log('=== DATABASE TEST START ===');
  
  try {
    // Test 1: Check if tables exist
    console.log('Test 1: Checking if tables exist...');
    const tables = await sql`SELECT type, name FROM sqlite_master WHERE type = 'table'`.execute(db);
    
    console.log('Tables found:', tables.rows.map((t: any) => t.name));
    
    // Test 2: Test service_requests table structure
    console.log('\nTest 2: Checking service_requests table structure...');
    const serviceRequestsInfo = await db.selectFrom('service_requests')
      .selectAll()
      .limit(1)
      .execute();
    console.log('service_requests table accessible:', serviceRequestsInfo.length >= 0);
    
    // Test 3: Try inserting a test record
    console.log('\nTest 3: Testing insert operation...');
    const testData = {
      client_name: 'Test Client',
      client_email: 'test@example.com',
      client_phone: '+265991451188',
      service_type: 'Test Service',
      location: 'Blantyre',
      description: 'Test description',
      urgent: 0,
      status: 'pending'
    };
    
    console.log('Inserting test data:', testData);
    
    const result = await db
      .insertInto('service_requests')
      .values(testData)
      .execute();
    
    console.log('Insert result:', result);
    
    if (result[0]?.insertId) {
      const insertId = Number(result[0].insertId);
      console.log('✅ Insert successful, ID:', insertId);
      
      // Test 4: Verify the record was inserted
      const verifyRecord = await db
        .selectFrom('service_requests')
        .selectAll()
        .where('id', '=', insertId)
        .execute();
      
      console.log('✅ Verification successful:', verifyRecord[0]);
      
      // Clean up test record
      await db
        .deleteFrom('service_requests')
        .where('id', '=', insertId)
        .execute();
      
      console.log('✅ Test record cleaned up');
    }
    
    console.log('\n=== DATABASE TEST COMPLETE - ALL TESTS PASSED ===');
    
  } catch (error) {
    console.error('=== DATABASE TEST FAILED ===');
    console.error('Error type:', error.constructor.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
  }
}

// Run the test
testDatabaseOperations();
